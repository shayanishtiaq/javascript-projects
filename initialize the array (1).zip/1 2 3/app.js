document.write("<b>a. Counting:</b> ");
for (let i = 1; i <= 15; i++) {
  document.write(i + ", ");
}
document.write("<br>");
document.write("<b>b. Reverse counting:</b> ");
for (let i = 10; i >= 1; i--) {
  document.write(i + ", ");
}
document.write("<br>");
document.write("<b>c. Even:</b> ");
for (let i = 0; i <= 20; i += 2) {
  document.write(i + ", ");
}
document.write("<br>");

document.write("<b>d. Odd:</b> ");
for (let i = 1; i <= 19; i += 2) {
  document.write(i + ", ");
}
document.write("<br>");

document.write("<b>e. Series:</b> ");
for (let i = 2; i <= 20; i += 2) {
  document.write(i + "k, ");
}
document.write("<br>");