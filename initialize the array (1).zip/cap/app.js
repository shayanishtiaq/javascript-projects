let userInput = prompt("Enter a string:");

let capitalizedInput = userInput.toUpperCase();

alert("Capitalized Input: " + capitalizedInput);
