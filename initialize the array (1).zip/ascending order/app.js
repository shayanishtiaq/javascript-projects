let scores = [85, 92, 78, 90, 88];

console.log("Initial scores:", scores);

scores.sort(function(a, b) {
  return a - b;
});

console.log("Sorted scores:", scores);
