let A = ["cake", "apple pie", "cookie", "chips", "patties"];

let userInput = prompt("Enter an item to search:");

userInput = userInput.toLowerCase();

let found = false;

for (let i = 0; i < A.length; i++) {
  if (A[i].toLowerCase() === userInput) {
    found = true;
    break;
  }
}

if (found) {
  alert("Yes, the item is found in the list.");
} else {
  alert("No, the item is not found in the list.");
}