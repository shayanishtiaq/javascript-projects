let colors = ["Red", "Green", "Blue", "Yellow"];

document.write("<b>Initial Array:</b> " + colors.join(", ") + "<br>");

let colorToAddAtStart = prompt("Enter a color to add at the beginning:");
colors.unshift(colorToAddAtStart);

document.write("<b>Array after adding color at the beginning:</b> " + colors.join(", ") + "<br>");

let colorToAddAtEnd = prompt("Enter a color to add at the end:");
colors.push(colorToAddAtEnd);

document.write("<b>Array after adding color at the end:</b> " + colors.join(", ") + "<br>");

colors.unshift("Purple", "Orange");

document.write("<b>Array after adding two more colors at the beginning:</b> " + colors.join(", ") + "<br>");

colors.shift();

document.write("<b>Array after deleting the first color:</b> " + colors.join(", ") + "<br>");
colors.pop();

document.write("<b>Array after deleting the last color:</b> " + colors.join(", ") + "<br>");

let indexToAdd = parseInt(prompt("Enter the index where you want to add a color:"));
let colorToAddAtIndex = prompt("Enter the color to add at index " + indexToAdd + ":");
colors.splice(indexToAdd, 0, colorToAddAtIndex);

document.write("<b>Array after adding color at index " + indexToAdd + ":</b> " + colors.join(", ") + "<br>");

let indexToDelete = parseInt(prompt("Enter the index from where you want to delete color(s):"));
let deleteCount = parseInt(prompt("Enter the number of colors to delete:"));
colors.splice(indexToDelete, deleteCount);

document.write("<b>Array after deleting " + deleteCount + " color(s) from index " + indexToDelete + ":</b> " + colors.join(", ") + "<br>");