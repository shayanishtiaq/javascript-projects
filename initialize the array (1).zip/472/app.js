let stringNumber = "472";
    let convertedNumber = Number(stringNumber);
    document.write("<b>String:</b> " + stringNumber + "<br>");
    document.write("<b>Type:</b> " + typeof stringNumber + "<br><br>");

    document.write("<b>Number:</b> " + convertedNumber + "<br>");
    document.write("<b>Type:</b> " + typeof convertedNumber + "<br>");