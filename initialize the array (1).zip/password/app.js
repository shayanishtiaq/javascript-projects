var correctPassword = "123";
var userInput = prompt("Please enter your password:");
if (userInput === "") {
    alert("Please enter your password");
} else if (userInput === correctPassword) {
    alert("Correct! The password you entered matches the original password");
} else {
    alert("Incorrect password");
}