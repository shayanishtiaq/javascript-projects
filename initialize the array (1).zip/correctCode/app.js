var greeting;
var hour = prompt("Enter number",13);
if (hour < 18) {
    greeting = "Good day";
} else {
    greeting = "Good evening";
}
alert(greeting);